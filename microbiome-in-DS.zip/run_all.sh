echo "Pre-processing the 16S data"
python 1_combining_files_16S.py
python 2_split_16S.py
python 2_normalize_16S.py
echo "Pre-processing the total RNA data"
python 1_combining_files_total_RNA.py
python 2_split_total_RNA.py
python 2_normalize_total_RNA.py
echo "Downstream analysis"
Rscript analysis.R
