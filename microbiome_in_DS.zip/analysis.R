### Figures:
# Differentially abundant species (DA) - DeSeq2
# Plotting the top DA species 
# Plotting the most abundant species in DS and in WT mice
# Venn diagrams of species present in WT and DS
# Multidimensional Scaling Analysis (MDS) 
# Hierarchical Clustering (HCL)
# Correlation of species within WT and DS mice
# Validation with total RNA HiSeq data - presence of species - Venn diagram
# Correlation of species abundances in 16S and total RNA HiSeq data

### Numbers of species detected in WT_T0, WT_T4, DS_T0, DS_T4 - TO CHYBA SKASOWAC ???
### Supplementary Data and Figures:
# Numbers of reads per sample in 16S data
# Numbers of reads per sample in total RNA data 
# Rarefaction curves in 16S data 
# Rarefaction curves in total RNA data 
# Validation with total RNA HiSeq data - presence of species - Venn diagram for each condition
# Correlation of species within WT and DS mice - validation in total RNA data

### Comparison with metadata and/or with the human data:

# Correlate species abundances changes with body weight gains (between T0 and T4) (mice only)
# Correlate species abundances with body weights (mice only)
#### in progress: Correlate species abundances with behavioral data (mice)
# Correlate changes in species abundances with behavioral data changes (between T0 and T4) (mice)


# Compare numbers of detected species in mice and human data (Biagi et al. 2014) (Venn diagram)
# Compare numbers of species (mice and humans) per genotype
# Correlate mouse with mouse abundances data and human with human, and compare them
# Correlate mice taxonomic abundances data with human taxonomic abundances data (TODO)
# Clustering of the human data alone
# Clustering of the human and mice data
# MDS on human metadata
# Correlate human microbiome data with metadata
# Build a model for predicting obesity or mental disability





# ANALYSIS:
#################### Differential taxa abundance in 16S data analysis - with DeSeq2 ####################

# if (!requireNamespace("BiocManager", quietly = TRUE))
  install.packages("BiocManager")

# BiocManager::install("DESeq2")
library("DESeq2")
# Species level
cts <- read.csv('split_file_combined_16S_S.csv', header=T, stringsAsFactors = F, row.names = 1) # choose a taxonomic level: 'P', 'C', 'O', 'F', 'G', 'S'
cts$level<-NULL # Counts table
cts$X<- NULL
colnames(cts) <- sub("X", "", colnames(cts))
coldata <- data.frame(matrix(nrow=ncol(cts),ncol=2)) # Metadata table
rownames(coldata) <- colnames(cts)
colnames(coldata) <- c('strain', 'day')
coldata$day <- factor(rep(c('0', '4'),12))
coldata$strain <- factor(c(rep('DS', 12), rep('WT', 12)))

dds <- DESeqDataSetFromMatrix(countData = cts, 
                              colData = coldata,
                              design = ~ strain)
keep <- rowMeans(counts(dds)) > 20 # removing taxa with low counts
dds <- dds[keep,]
#dds$day <- factor(dds$day, levels = c("0","4")) # timepoints analysis
dds$strain <- factor(dds$strain, levels = c("WT","DS")) # mouse strains analysis
dds <- DESeq(dds)
res <- results(dds)
resOrdered_S <- data.frame(res[order(res$pvalue),])
write.csv(resOrdered_S, 'S_genotype.csv')

# Phylum level:
cts <- read.csv('split_file_combined_16S_P.csv', header=T, stringsAsFactors = F, row.names = 1) # choose a taxonomic level: 'P', 'C', 'O', 'F', 'G', 'S'
cts$level<-NULL # Counts table
cts$X<- NULL
colnames(cts) <- sub("X", "", colnames(cts))
coldata <- data.frame(matrix(nrow=ncol(cts),ncol=2)) # Metadata table
rownames(coldata) <- colnames(cts)
colnames(coldata) <- c('strain', 'day')
coldata$day <- factor(rep(c('0', '4'),12))
coldata$strain <- factor(c(rep('DS', 12), rep('WT', 12)))

dds <- DESeqDataSetFromMatrix(countData = cts, 
                              colData = coldata,
                              design = ~ strain)
keep <- rowMeans(counts(dds)) > 20 # removing taxa with low counts
dds <- dds[keep,]
#dds$day <- factor(dds$day, levels = c("0","4")) # timepoints analysis
dds$strain <- factor(dds$strain, levels = c("WT","DS")) # mouse strains analysis
dds <- DESeq(dds)
res <- results(dds)
resOrdered_P <- data.frame(res[order(res$pvalue),])
write.csv(resOrdered_P, 'P_genotype.csv')

### Comparing diets separately in WT and DS mice
# WT:
cts <- read.csv('split_file_combined_16S_S.csv', header=T, stringsAsFactors = F, row.names = 1) # choose a taxonomic level: 'P', 'C', 'O', 'F', 'G', 'S'
cts$level<-NULL # Counts table
cts$X<- NULL
colnames(cts) <- sub("X", "", colnames(cts))
cts_WT <- cts[,grepl('6684|6686|6687|6690|6691|6694', colnames(cts))]
coldata_WT <- data.frame(matrix(nrow=ncol(cts_WT),ncol=1)) # Metadata table
rownames(coldata_WT) <- colnames(cts_WT)
colnames(coldata_WT) <- c('day')
coldata_WT$day <- factor(rep(c('4', '0'),6))

dds <- DESeqDataSetFromMatrix(countData = cts_WT, 
                              colData = coldata_WT,
                              design = ~ day)
keep <- rowMeans(counts(dds)) > 20 # removing taxa with low counts
dds <- dds[keep,]
dds$day <- factor(dds$day, levels = c("0","4")) # timepoints analysis
dds <- DESeq(dds)
res <- results(dds)
resOrdered_WT <- data.frame(res[order(res$pvalue),])
write.csv(resOrdered_WT, 'S_diet_WT.csv')

# DS:
cts_DS <- cts[,grepl('6696|6697|6698|6700|6701|6702', colnames(cts))]
coldata_DS <- data.frame(matrix(nrow=ncol(cts_DS),ncol=1)) # Metadata table
rownames(coldata_DS) <- colnames(cts_DS)
colnames(coldata_DS) <- c('day')
coldata_DS$day <- factor(rep(c('4', '0'),6))

dds <- DESeqDataSetFromMatrix(countData = cts_DS, 
                              colData = coldata_DS,
                              design = ~ day)
keep <- rowMeans(counts(dds)) > 20 # removing taxa with low counts
dds <- dds[keep,]
dds$day <- factor(dds$day, levels = c("0","4")) # timepoints analysis
dds <- DESeq(dds)
res <- results(dds)
resOrdered_DS <- data.frame(res[order(res$pvalue),])
write.csv(resOrdered_DS, 'S_diet_DS.csv')


#################### Plotting the top DA species #################### 
library(plyr)
library(data.table)
library(ggplot2)
library(scales) 
library(dplyr)
data <- read.csv('split_file_combined_normalized_16S_S.csv', header=T, stringsAsFactors = F) 
data$level <- data$X <- NULL
colnames(data) <- c('taxon', 'WT1_T4', 'WT1_T0', 'WT2_T4', 'WT2_T0', 'WT3_T4', 'WT3_T0', 'WT4_T4', 'WT4_T0', 'WT5_T4', 'WT5_T0', 'WT6_T4', 'WT6_T0',
                    'DS1_T4', 'DS1_T0', 'DS2_T4', 'DS2_T0', 'DS3_T4', 'DS3_T0', 'DS4_T4', 'DS4_T0', 'DS5_T4', 'DS5_T0', 'DS6_T4', 'DS6_T0')

DA_species <- row.names(resOrdered_S[2,])
#DA_species <- row.names(resOrdered[21,])
data_plot_DA <- data[data$taxon==DA_species,]
data_plot_DA <- melt(data_plot_DA)
data_plot_DA$strain <- NA
data_plot_DA$strain[ grepl('WT', data_plot_DA$variable)] <- 'WT'
data_plot_DA$strain[ grepl('DS', data_plot_DA$variable)] <- 'DS'

ggplot(data_plot_DA, aes(x = strain, y = value, color = strain)) +
  geom_jitter(size=5, alpha = 0.5, width=0.2) +
  scale_y_continuous(labels = comma) +
  guides(color=guide_legend(title="Mouse strain")) +
  xlab('Mouse strain') +
  ylab(paste0(DA_species, '\nnormalized counts'))
ggsave(paste0(DA_species, '_normalized_counts.png'))

#################### Plotting the most abundant species in DS and in WT mice #################### 

## Species ##
data <- read.csv('split_file_combined_normalized_16S_S.csv', header=T, stringsAsFactors = F) 
data$level <- data$X <- NULL
colnames(data) <- c('taxon', 'WT1_T4', 'WT1_T0', 'WT2_T4', 'WT2_T0', 'WT3_T4', 'WT3_T0', 'WT4_T4', 'WT4_T0', 'WT5_T4', 'WT5_T0', 'WT6_T4', 'WT6_T0',
                    'DS1_T4', 'DS1_T0', 'DS2_T4', 'DS2_T0', 'DS3_T4', 'DS3_T0', 'DS4_T4', 'DS4_T0', 'DS5_T4', 'DS5_T0', 'DS6_T4', 'DS6_T0')

data_plot<- data
data_plot$median <- apply(data_plot[grepl('_', colnames(data_plot))], 1, median)
data_plot <- arrange(data_plot, desc(median))
data_plot <- data_plot[1:20,]
data_plot$median <- NULL
taxon_order <- c(data_plot$taxon)
data_plot <- melt(data_plot)
data_plot$strain <- NA
data_plot$strain[ grepl('WT', data_plot$variable)] <- 'WT'
data_plot$strain[ grepl('DS', data_plot$variable)] <- 'DS'

data_plot$taxon <- factor(as.character(data_plot$taxon), levels = taxon_order) # setting order of the x axis
data_plot$significance <- NA
for (i in 1:nrow(data_plot)) {
  species <- as.character(data_plot$taxon[i])
  print(species)
  if (!is.na(resOrdered_S[species, "padj"])) {
    if (resOrdered_S[species, "padj"]<0.05) {
    data_plot$significance[i] <- '*'
    }
  }
}

ggplot(data_plot, aes(x=taxon, y=value, fill=strain)) + 
   geom_boxplot() +
   scale_y_continuous(trans='log10',
                      breaks = trans_breaks("log10", function(x) 10^x),
                      labels = trans_format("log10", math_format(10^.x))) +
   xlab('Species') +
   ylab( 'Log10(normalized mean number of \nreads / sample)') +
   theme(axis.text.x = element_text(angle = 90, hjust = 1)) +
  guides(fill=guide_legend(title="Mouse strain")) +
  geom_text(x = 1:nrow(data_plot), y = 5.2, label=data_plot$significance, size=7) 
ggsave('Top_20_abundant_species.png')

## Phyla ##
data_phyla <- read.csv('split_file_combined_normalized_16S_P.csv', header=T, stringsAsFactors = F) 
data_phyla$level <- data_phyla$X <- NULL
colnames(data_phyla) <- c('taxon', 'WT1_T4', 'WT1_T0', 'WT2_T4', 'WT2_T0', 'WT3_T4', 'WT3_T0', 'WT4_T4', 'WT4_T0', 'WT5_T4', 'WT5_T0', 'WT6_T4', 'WT6_T0',
                    'DS1_T4', 'DS1_T0', 'DS2_T4', 'DS2_T0', 'DS3_T4', 'DS3_T0', 'DS4_T4', 'DS4_T0', 'DS5_T4', 'DS5_T0', 'DS6_T4', 'DS6_T0')

data_plot<- data_phyla
data_plot$median <- apply(data_plot[grepl('_', colnames(data_plot))], 1, median)
data_plot <- arrange(data_plot, desc(median))
data_plot <- data_plot[1:20,]
data_plot$median <- NULL
taxon_order <- c(data_plot$taxon)
data_plot <- melt(data_plot)
data_plot$strain <- NA
data_plot$strain[ grepl('WT', data_plot$variable)] <- 'WT'
data_plot$strain[ grepl('DS', data_plot$variable)] <- 'DS'

data_plot$taxon <- factor(as.character(data_plot$taxon), levels = taxon_order) # setting order of the x axis
data_plot$significance <- NA
for (i in 1:nrow(data_plot)) {
  species <- as.character(data_plot$taxon[i])
  print(species)
  if (!is.na(resOrdered_P[species, "padj"])) {
    if (resOrdered_P[species, "padj"]<0.05) {
      data_plot$significance[i] <- '*'
    }
  }
}

ggplot(data_plot, aes(x=taxon, y=value, fill=strain)) + 
  geom_boxplot() +
  scale_y_continuous(trans='log10',
                     breaks = trans_breaks("log10", function(x) 10^x),
                     labels = trans_format("log10", math_format(10^.x))) +
  xlab('Phyla') +
  ylab( 'Log10(mean number of reads / sample)') +
  theme(axis.text.x = element_text(angle = 90, hjust = 1)) +
  guides(fill=guide_legend(title="Mouse strain")) +
  geom_text(x = 1:nrow(data_plot), y = 5.2, label=data_plot$significance, size=7)
ggsave('Top_20_abundant_phyla.png')

#################### Venn diagrams #################### 
library(venn)

data_venn <- data[,c(2:ncol(data))]
rownames(data_venn) <- data$taxon
data_venn <- data_venn[rowSums(data_venn)>19,] #removing low-count species
DS <- row.names(data_venn[rowSums(data_venn[,grepl('DS.*T0', colnames(data_venn))])>0,])
WT <- row.names(data_venn[rowSums(data_venn[,grepl('WT.*T0', colnames(data_venn))])>0,])

input <- list(DS, WT)
pdf('venn_WT_DS_control.pdf', width = 4, height = 4)
venn(input, snames = c('DS', 'WT'), zcolor = c('#F8766D', '#00BFC4'))
dev.off()

#library(eulerr)
#plot(euler(list(DS = DS, WT = WT)), fills = c('#F8766D', '#00BFC4'))

#################### Multidimensional Scaling Analysis #################### 

library(vegan)
data_mds <- data
rownames(data_mds) <- data_mds$taxon
data_mds$taxon <- NULL
data_mds <- data_mds[rowSums(data_mds)>19,] #removing low-count species
data_mds<-data.frame(t(data_mds))

data.classes.genotype<-c(rep('#00BFC4', 12), rep('#F8766D', 12)) # c(rep('DN', 12), rep('WT', 12))
data.classes.day<-c(rep(c(1, 2),12)) # c(rep(c('T0', 'T4'),12))

# https://websites.pmc.ucsc.edu/~mclapham/Rtips/ordination.htm
PCoA.res<-capscale(data_mds~1,distance="canberra", dfun=vegdist) #bray
eig<-PCoA.res$CA$eig # percentages of each MDS component
percentages_explained <- eig / sum(eig)

png('MDS_species_Bray_strain_MDS3.png')
plot(scores(PCoA.res, choices=c(3,4), display="sites"), col=data.classes.genotype, pch=19, xlab = paste(c("MDS3 \n", as.character(round(percentages_explained[[3]]*100, 2)) , "%"), collapse=""))
#dis <- vegdist(data_mds,method="canberra")
#text(scores(PCoA.res, choices=c(3,4), display="sites"), labels(dis), col=data.classes.genotype, pos=1)
mtext(side = 2, text = paste(c(as.character(round(percentages_explained[[4]]*100, 2)) , "%"), collapse=""), line = 2)
legend("topleft", c('WT', 'DS'), pch=19, col=c('#00BFC4','#F8766D'))
dev.off()

scores<-data.frame(scores(PCoA.res, choices=c(3,4), display="species"))
order<-order(abs(scores$MDS3), decreasing=TRUE)
scores[order,]
write.table(scores[order,], file="Scores_MDS_Bray_S_strains.csv", sep=',', row.names = TRUE, col.names = TRUE)


#################### Hierarchical Clustering #################### 

library(vegan)
library(dendextend)

data_hcl <- data
rownames(data_hcl) <- data_hcl$taxon
data_hcl$taxon <- NULL
data_hcl <- data_hcl[rowSums(data_hcl)>19,]
data_hcl<-data.frame(t(data_hcl))
dist_matr <- vegdist(data_hcl,method="bray") 
dend<-as.dendrogram(hclust(dist_matr, method='ward.D')) ##
labels_colors(dend)<-c(rep('#00BFC4', 8), '#F8766D', rep('#00BFC4', 3), '#F8766D', '#00BFC4', rep('#F8766D', 10))
png(file="HCL_strain_S.png")
par(mar=c(5,4.1,2.1,2.1))
plot(dend)
legend("topright", c('WT', 'DS'), pch=19, col=c('#00BFC4', '#F8766D'))
dev.off()

dev.off() # Resetting par()

#################### Correlation of species within WT and DS mice #################### 

library(ggplot2)
library(scales)
library(ggrepel)
library(data.table)
library(reshape2)
library(grid)

data_corr <- data
row.names(data_corr) <- data_corr$taxon
data_corr$taxon <- NULL
data_corr <- data_corr[rowSums(data_corr)>19,]

WT_T0 <- colnames(data_corr)[grepl('WT.*T0', colnames(data_corr))]
mice1 <- WT_T0
mice2 <- mice1 [ mice1 != mice1[1]]
WT_T0_kor <- c()
WT_T0_p <- c()
cnt<-0
for (i in mice1) {
  for (j in mice2) {
    if (i!=j){
      cat(i, ' ', j, '\n')
      k<- cor.test(data_corr[,i], data_corr[,j])
      WT_T0_kor <- c(WT_T0_kor, k$estimate)
      WT_T0_p <- c(WT_T0_p, k$p.value)
      cnt<-cnt+1 } } 
  mice2 <- mice2 [ mice2!=i ]
}

WT_T4 <- colnames(data_corr)[grepl('WT.*T4', colnames(data_corr))]
mice1<- WT_T4
mice2 <- mice1 [ mice1 != mice1[1]]
WT_T4_kor <- c()
WT_T4_p <- c()
cnt<-0
for (i in mice1) {
  for (j in mice2) {
    if (i!=j){
      cat(i, ' ', j, '\n')
      k<- cor.test(data_corr[,i], data_corr[,j])
      WT_T4_kor <- c(WT_T4_kor, k$estimate)
      WT_T4_p <- c(WT_T4_p, k$p.value)
      cnt<-cnt+1 } } 
  mice2 <- mice2 [ mice2!=i ]
}

DS_T0 <- colnames(data_corr)[grepl('DS.*T0', colnames(data_corr))]
mice1<- DS_T0
mice2 <- mice1 [ mice1 != mice1[1]]
DS_T0_kor <- c()
DS_T0_p <- c()
cnt<-0
for (i in mice1) {
  for (j in mice2) {
    if (i!=j){
      cat(i, ' ', j, '\n')
      k<- cor.test(data_corr[,i], data_corr[,j])
      DS_T0_kor <- c(DS_T0_kor, k$estimate)
      DS_T0_p <- c(DS_T0_p, k$p.value)
      cnt<-cnt+1 } } 
  mice2 <- mice2 [ mice2!=i ]
}

DS_T4 <- colnames(data_corr)[grepl('DS.*T4', colnames(data_corr))]
mice1<- DS_T4
mice2 <- mice1 [ mice1 != mice1[1]]
DS_T4_kor <- c()
DS_T4_p <- c()
cnt<-0
for (i in mice1) {
  for (j in mice2) {
    if (i!=j){
      cat(i, ' ', j, '\n')
      k<- cor.test(data_corr[,i], data_corr[,j])
      DS_T4_kor <- c(DS_T4_kor, k$estimate)
      DS_T4_p <- c(DS_T4_p, k$p.value)
      cnt<-cnt+1 } } 
  mice2 <- mice2 [ mice2!=i ]
}
# 
# WT_T0_kor
# WT_T4_kor
# DS_T0_kor
# DS_T4_kor

data_plot_corr <- data.frame('WT_T0' = c(WT_T0_kor),
                   'WT_T4' = c(WT_T4_kor),
                   'DS_T0' = c(DS_T0_kor),
                   'DS_T4' = c(DS_T4_kor) )

data_plot_corr<-melt(data_plot_corr)

ggplot(data_plot_corr, aes(x=variable, y=value)) +
  geom_boxplot(fill = c('#00BFC4', '#00BFC4', '#F8766D', '#F8766D'), alpha =0.8) +
  ylab('Pearson R') + xlab('Condition') +
  scale_y_continuous(breaks = seq(0, 1, by = 0.1))

ggsave('correlations_of_samples_within_conditions.png')

wilcox.test(c(WT_T0_kor, WT_T4_kor), c(DS_T0_kor, DS_T4_kor))
wilcox.test(c(WT_T0_kor, DS_T0_kor), c(WT_T4_kor, DS_T4_kor))
median(c(as.numeric(WT_T0_kor), as.numeric(WT_T4_kor)))
median(c(as.numeric(WT_T0_p), as.numeric(WT_T4_p)))
median(c(as.numeric(DS_T0_kor), as.numeric(DS_T4_kor)))
median(c(as.numeric(DS_T0_p), as.numeric(DS_T4_p)))
median(c(as.numeric(DS_T0_kor)))
median(c(as.numeric(DS_T4_kor)))
median(c(as.numeric(WT_T0_kor)))
median(c(as.numeric(WT_T4_kor)))

################### Validation with total RNA HiSeq data - presence of species ################### 

library(venn)

data_venn <- data[,c(2:ncol(data))]
rownames(data_venn) <- data$taxon
#data_venn <- data_venn[rowSums(data_venn)>19,] #removing low-count species

data_total_rna <- read.csv('split_file_combined_total_RNA_S.csv', header=T, stringsAsFactors = F, row.names = 1) 
data_total_rna$level <- NULL
colnames(data_total_rna) <- c('WT7_T3', 'DS7_T3', 'DS7_T1', 'DS8_T3', 'WT8_T3', 'WT4_T3', 'WT4_T1', 'WT7_T1', 'DS8_T1')

sequencing_16S <- row.names(data_venn)
sequencing_total_RNA <- row.names(data_total_rna)
input <- list(sequencing_16S, sequencing_total_RNA)
# pdf('venn_sequencing_16S_and_totalRNA.pdf', width = 4, height = 4)
# detach("package:eulerr", unload=TRUE)
# venn(input, snames = c('16S', 'total RNA'), zcolor = c('green', 'gray'))
# dev.off()

library(eulerr)
pdf('venn_sequencing_16S_and_totalRNA.pdf', width = 4, height = 4)
plot(euler(list('16S' = sequencing_16S, 'total RNA' = sequencing_total_RNA)), fills = c('green', 'gray'))
dev.off()

################### Correlation of species abundances in 16S and total RNA HiSeq data ################### 

library(ggplot2)
library(scales)
library(ggrepel)
library(grid)

data_16s <- data
row.names(data_16s) <- data_16s$taxon
data_16s$taxon <- NULL
data_16s <- data_16s[rowSums(data_16s)>19,]
data_16s$mean <- apply(data_16s, 1, mean)

data_total_rna <- read.csv('split_file_combined_total_RNA_S.csv', header=T, stringsAsFactors = F, row.names = 1) 
colnames(data_total_rna) <- c('level', 'WT7_T3', 'DS7_T3', 'DS7_T1', 'DS8_T3', 'WT8_T3', 'WT4_T3', 'WT4_T1', 'WT7_T1', 'DS8_T1', 'X')
data_total_rna$level <- data_total_rna$X <- NULL
data_total_rna <- data_total_rna[rowSums(data_total_rna)>10,]
data_total_rna$mean <- apply(data_total_rna, 1, mean)

species <- rownames(data_total_rna)[rownames(data_total_rna)%in%rownames(data_16s)]

b2 <- b3 <-c()
for (sp in species) {
  b2 <- c(b2, data_total_rna$mean[rownames(data_total_rna)==sp])
  b3 <- c(b3, data_16s$mean[rownames(data_16s)==sp])
}

korelacja <- cor.test(b2, b3)
grob <- grobTree(textGrob(paste0('Pearson R = ', round(korelacja$estimate, digits=2), '\np-val = ', signif(korelacja$p.value, digits=3) ), x=0.1,  y=0.95, hjust=0, gp=gpar(fontface="bold")))
data <- data.frame(b2, b3)
ggplot(data, aes(x=b2, y=b3)) +
  geom_point() +
  scale_x_continuous(trans = log2_trans(),
                     breaks = trans_breaks("log2", function(x) 2^x),
                     labels = trans_format("log2", math_format(2^.x)), name='Total RNA: log2 (mean of species abundances in all mice)') +
  scale_y_continuous(trans = log2_trans(),
                     breaks = trans_breaks("log2", function(x) 2^x),
                     labels = trans_format("log2", math_format(2^.x)), name='16S: log2 (mean of species abundances in all mice)') +
  annotation_custom(grob) 
ggsave('correlation_of_data_total_rna_and_data_16s_species_abundances_means_over_mice.png')



####### SUPPLEMENTARY FIGURES / NUMBERS ####### :

#################### Numbers of reads per sample in 16S data #################### 

all_counts <- read.csv('files_combined_SK_16S.csv', stringsAsFactors = T, header=T, nrows = 2, row.names = 1)
all_counts$X <- all_counts$level <- NULL
all_reads <- all_counts["root",] +all_counts["unclassified",] 
sum(all_reads)
median(as.numeric(all_reads))
min(as.numeric(all_reads))
max(as.numeric(all_reads))

#################### Numbers of reads per sample in total RNA data #################### 

all_counts_total <- read.csv('files_combined_SK_total_paired.csv', header=T, nrow = 2, stringsAsFactors = F, row.names = 1) 
all_counts_total$X <- all_counts_total$level <- NULL
all_reads_total <- all_counts_total["root",] +all_counts_total["unclassified",] 
sum(all_reads_total)
median(as.numeric(all_reads_total))
min(as.numeric(all_reads_total))
max(as.numeric(all_reads_total))

################### Rarefaction curves in 16S data #################### 

library(randomcoloR)
data_rarefaction <- read.csv('split_file_combined_16S_S.csv', header=T, stringsAsFactors = F, row.names = 1)
data_rarefaction$level <- data_rarefaction$X <- NULL
colnames(data_rarefaction) <- c('WT1_T4', 'WT1_T0', 'WT2_T4', 'WT2_T0', 'WT3_T4', 'WT3_T0', 'WT4_T4', 'WT4_T0', 'WT5_T4', 'WT5_T0', 'WT6_T4', 'WT6_T0',
                    'DS1_T4', 'DS1_T0', 'DS2_T4', 'DS2_T0', 'DS3_T4', 'DS3_T0', 'DS4_T4', 'DS4_T0', 'DS5_T4', 'DS5_T0', 'DS6_T4', 'DS6_T0')


funkcja <- function (repeats, sample_min, sample_max, by_how_many) {
  counting <- means <- c()
  x <- seq(sample_min, sample_max, by=by_how_many)
  for (sampl in x) {
    counting <- c()
    for (rep in 1:repeats) {
      species_nr <- length(unique(sample(species, size = sampl, prob = probs, replace=T)))
      counting <- c(counting, species_nr)
    }
    means <- c(means, mean(counting))
  }
  y <- means
  return(list(sample_max,y))
}
species <- rownames(data_rarefaction)

png('Rarefaction_curve_with_species_16S.png')
plot (seq(0, 250000, by=10000), c(rep(0,25),400), type = 'n', xlab = 'Number of sequences drawn', ylab='Number of unique species', main='Rarefaction curve for species')
for (kolumna in 1:ncol(data_rarefaction)) {
  print(colnames(data_rarefaction[kolumna]) )
  probs <- data_rarefaction[,kolumna] / sum(data_rarefaction[,kolumna])
  serie <- funkcja (20, 0, sum(data_rarefaction[,kolumna]), 10000)[[2]]
  lines(seq(0, sum(data_rarefaction[,kolumna]), by=10000), serie, col=randomColor(kolumna))
}
#legend('right', leg.txt, col=colors, lty=c(1,1))
dev.off()

################### Rarefaction curves in total RNA data #################### 

library(randomcoloR)
data_rarefaction <- read.csv('split_file_combined_total_RNA_S.csv', header=T, stringsAsFactors = F, row.names = 1)
colnames(data_rarefaction) <- c('level', 'WT7_T3', 'DS7_T3', 'DS7_T1', 'DS8_T3', 'WT8_T3', 'WT4_T3', 'WT4_T1', 'WT7_T1', 'DS8_T1', 'X')
data_rarefaction$level <- data_rarefaction$X <- NULL

funkcja <- function (repeats, sample_min, sample_max, by_how_many) {
  counting <- means <- c()
  x <- seq(sample_min, sample_max, by=by_how_many)
  for (sampl in x) {
    counting <- c()
    for (rep in 1:repeats) {
      species_nr <- length(unique(sample(species, size = sampl, prob = probs, replace=T)))
      counting <- c(counting, species_nr)
    }
    means <- c(means, mean(counting))
  }
  y <- means
  return(list(sample_max,y))
}
species <- rownames(data_rarefaction)

png('Rarefaction_curve_with_species_total_RNA.png')
plot (seq(0, 10000000, by=1000000), c(rep(0,10),2000), type = 'n', xlab = 'Number of sequences drawn', ylab='Number of unique species', main='Rarefaction curve for species')
for (kolumna in 1:ncol(data_rarefaction)) {
  print(colnames(data_rarefaction[kolumna]) )
  probs <- data_rarefaction[,kolumna] / sum(data_rarefaction[,kolumna])
  serie <- funkcja (1, 0, sum(data_rarefaction[,kolumna]), 500000)[[2]]
  lines(seq(0, sum(data_rarefaction[,kolumna]), by=500000), serie, col=randomColor(kolumna))
}
#legend('right', leg.txt, col=colors, lty=c(1,1))
dev.off()


#################### Validation with total RNA HiSeq data - presence of species - Venn diagram for each condition #################### 

library(venn)
data <- read.csv('split_file_combined_normalized_16S_S.csv', header=T, stringsAsFactors = F) 
data$level <- data$X <- NULL
colnames(data) <- c('taxon', 'WT1_T4', 'WT1_T0', 'WT2_T4', 'WT2_T0', 'WT3_T4', 'WT3_T0', 'WT4_T4', 'WT4_T0', 'WT5_T4', 'WT5_T0', 'WT6_T4', 'WT6_T0',
                    'DS1_T4', 'DS1_T0', 'DS2_T4', 'DS2_T0', 'DS3_T4', 'DS3_T0', 'DS4_T4', 'DS4_T0', 'DS5_T4', 'DS5_T0', 'DS6_T4', 'DS6_T0')

data_venn <- data[,c(2:ncol(data))]
rownames(data_venn) <- data$taxon

data_total_rna <- read.csv('split_file_combined_total_RNA_S.csv', header=T, stringsAsFactors = F, row.names = 1) 
colnames(data_total_rna) <- c('level', 'WT7_T3', 'DS7_T3', 'DS7_T1', 'DS8_T3', 'WT8_T3', 'WT4_T3', 'WT4_T1', 'WT7_T1', 'DS8_T1', 'X')
data_total_rna$level <- data_total_rna$X <- NULL

# WT
sequencing_16S <- data_venn[,colnames(data_venn[grepl('WT', colnames(data_venn))])]
sequencing_16S <- sequencing_16S[rowSums(sequencing_16S)>0,]
sequencing_16S <- rownames(sequencing_16S)

sequencing_total_RNA <- data_total_rna[,colnames(data_total_rna[grepl('WT', colnames(data_total_rna))])]
sequencing_total_RNA <- sequencing_total_RNA[rowSums(sequencing_total_RNA)>0,]
sequencing_total_RNA <- row.names(sequencing_total_RNA)

input <- list(sequencing_16S, sequencing_total_RNA)


library(eulerr)
pdf('venn_sequencing_16S_and_totalRNA_WT.pdf', width = 4, height = 4)
plot(euler(list('16S' = sequencing_16S, 'total RNA' = sequencing_total_RNA)), fills = c('green', 'gray'))
dev.off()

# detach("package:eulerr", unload=TRUE)
# pdf('venn_sequencing_16S_and_totalRNA_WT.pdf', width = 4, height = 4)
# venn(input, snames = c('16S', 'total RNA'), zcolor = c('green', 'gray'))
# dev.off()

# DS

sequencing_16S <- data_venn[,colnames(data_venn[grepl('DS', colnames(data_venn))])]
sequencing_16S <- sequencing_16S[rowSums(sequencing_16S)>0,]
sequencing_16S <- rownames(sequencing_16S)

sequencing_total_RNA <- data_total_rna[,colnames(data_total_rna[grepl('DS', colnames(data_total_rna))])]
sequencing_total_RNA <- sequencing_total_RNA[rowSums(sequencing_total_RNA)>0,]
sequencing_total_RNA <- row.names(sequencing_total_RNA)

input <- list(sequencing_16S, sequencing_total_RNA)

library(eulerr)
pdf('venn_sequencing_16S_and_totalRNA_DS.pdf', width = 4, height = 4)
plot(euler(list('16S' = sequencing_16S, 'total RNA' = sequencing_total_RNA)), fills = c('green', 'gray'))
dev.off()
# 
# detach("package:eulerr", unload=TRUE)
# pdf('venn_sequencing_16S_and_totalRNA_DS.pdf', width = 4, height = 4)
# venn(input, snames = c('16S', 'total RNA'), zcolor = c('green', 'gray'))
# dev.off()

#################### Correlation of species within WT and DS mice - validation in total RNA HiSeq data #################### 

library(ggplot2)
library(scales)
library(ggrepel)
library(data.table)
library(reshape2)
library(grid)

data_total_rna <- data_total_rna
data_total_rna <- data_total_rna[rowSums(data_total_rna)>19,]

# Only WT and DS

WT_total <- colnames(data_total_rna)[grepl('WT', colnames(data_total_rna))]
mice1 <- WT_total
mice2 <- mice1 [ mice1 != mice1[1]]
WT_total_kor <- c()
WT_total_p <- c()
cnt<-0
for (i in mice1) {
  for (j in mice2) {
    if (i!=j){
      cat(i, ' ', j, '\n')
      k<- cor.test(data_total_rna[,i], data_total_rna[,j])
      WT_total_kor <- c(WT_total_kor, k$estimate)
      WT_total_p <- c(WT_total_p, k$p.value)
      cnt<-cnt+1 } } 
  mice2 <- mice2 [ mice2!=i ]
}

DS_total <- colnames(data_total_rna)[grepl('DS', colnames(data_total_rna))]
mice1<- DS_total
mice2 <- mice1 [ mice1 != mice1[1]]
DS_total_kor <- c()
DS_total_p <- c()
cnt<-0
for (i in mice1) {
  for (j in mice2) {
    if (i!=j){
      cat(i, ' ', j, '\n')
      k<- cor.test(data_total_rna[,i], data_total_rna[,j])
      DS_total_kor <- c(DS_total_kor, k$estimate)
      DS_total_p <- c(DS_total_p, k$p.value)
      cnt<-cnt+1 } } 
  mice2 <- mice2 [ mice2!=i ]
}

data_plot_corr_total <- setNames(data.frame(matrix(ncol = 2, nrow = length(WT_total_kor))), c("WT_total", "DS_total"))
data_plot_corr_total$WT_total <- WT_total_kor
data_plot_corr_total$DS_total[1:length(DS_total_kor)] <- DS_total_kor

data_plot_corr_total<-melt(data_plot_corr_total)

ggplot(data_plot_corr_total, aes(x=variable, y=value)) +
  geom_boxplot(fill = c('#00BFC4', '#F8766D'), alpha =0.8) +
  ylab('Pearson R') + xlab('Mouse strain') +
  scale_x_discrete (labels = c('WT', 'DS')) +
  scale_y_continuous(breaks = seq(0, 1, by = 0.1))

ggsave('correlations_of_samples_within_conditions_total_RNA.png')

wilcox.test(WT_total_kor, DS_total_kor)

median(as.numeric(WT_total_kor))
median(as.numeric(DS_total_kor))

median(as.numeric(WT_total_p))
median(as.numeric(DS_total_p))

#################### Comparison with metadata and/or with the human data: ####################

#################### Correlate species changes with body weight gains (mice only) ####################

# library(plyr)
# library(data.table)
# library(ggplot2)
# library(scales)
# library(dplyr)
# 
# for (level in c('P', 'C', 'O', 'F', 'G', 'S')){
#   data <- read.csv(paste0('split_file_combined_normalized_16S_', level, '.csv'), header=T, stringsAsFactors = F) 
#   data$level <- data$X <- NULL
#   body_weight <- read.csv('./mice_weights_T0_T4.csv', header=T, stringsAsFactors = F, row.names = 1)
#   body_weight <- body_weight[c('HB3', 'W4'),]
#   body_weight[3,]<- body_weight[2,]-body_weight[1,]
#   body_weight[4,]<- body_weight[3,]/body_weight[1,]*100
#   rownames(body_weight)<-c('T0', 'T4', 'bw_gain', 'bw_gain_percent')
#   species_gains <- data
#   rownames(species_gains) <- species_gains$taxon
#   species_gains$taxon <- NULL
#   species_gains <- species_gains[rowSums(species_gains)>19,]
#   
#   t4 <- seq(1, 24, by=2)
#   t0 <- seq(2, 24, by=2)
#   species_gains <- species_gains[,t4] - species_gains[,t0]
#   colnames(species_gains) <- substr(colnames(species_gains), 1, 5)
#   
#   correlations <- p_vals <- c()
#   for (row in 1:nrow(species_gains)){
#     cor <- cor.test(as.numeric(body_weight[4,]), as.numeric(species_gains[row,]), method='spearman')
#     correlations <- c(correlations, cor$estimate)
#     p_vals <- c(p_vals, cor$p.value)
#   }
#   species_gains$rho <- correlations
#   species_gains$p_val <- p_vals
#   species_gains$p_val_corr <- p_vals*nrow(species_gains)
#   species_gains$taxon<-rownames(species_gains)
#   species_gains <- arrange(species_gains, p_val)
#   write.csv(species_gains, paste0('./correlations_microbiome_weight/microbiome_changes_mice_weights_gains_correlation_', level, '.csv'))
#   which(apply(species_gains, 1, function(row) all(row <= 0))) # which species have all decreased with time - NONE
#   which(apply(species_gains, 1, function(row) all(row >= 0))) # which species have all increased with time - NONE
#   # None of the species has a signficant correlation with the body weight gain
#   for (i in 1:nrow(species_gains[species_gains$p_val<0.05,])) {
#     png(paste0('./correlations_microbiome_weight/Correlation_', level, '_', species_gains$taxon[i], '_gains.png'))
#     print(plot(as.numeric(species_gains[i,1:12]), as.numeric(body_weight[4,]), xlab = 'Taxon abundance change', ylab = 'body weight gains', 
#                main = paste0(species_gains$taxon[i], '\nSpearman rho = ', round(species_gains$rho[i], 2),
#                              '\np-val = ', round(species_gains$p_val[i], 2))))
#     dev.off()
#   }
# }
# 
# de_taxa <- rownames(resOrdered_S[resOrdered_S$padj<0.05,])
# species_gains[species_gains$taxon%in%de_taxa,]

############# Correlate species abundances with bw gains
#for (level in c('P', 'C', 'O', 'F', 'G', 'S')){
  data <- read.csv(paste0('split_file_combined_normalized_16S_', level, '.csv'), header=T, stringsAsFactors = F) 
  data$level <- data$X <- NULL
  body_weight <- read.csv('./mice_weights_T0_T4.csv', header=T, stringsAsFactors = F, row.names = 1)
  body_weight <- body_weight[c('HB3', 'W4'),]
  body_weight[3,]<- body_weight[2,]-body_weight[1,]
  body_weight[4,]<- body_weight[3,]/body_weight[1,]*100
  rownames(body_weight)<-c('T0', 'T4', 'bw_gain', 'bw_gain_percent')
  species_gains <- data
  rownames(species_gains) <- species_gains$taxon
  species_gains$taxon <- NULL
  species_gains <- species_gains[rowSums(species_gains)>19,]
  
  t4 <- seq(1, 24, by=2)
  t0 <- seq(2, 24, by=2)
  #species_gains <- species_gains[,t4] - species_gains[,t0]
  colnames(species_gains) <- substr(colnames(species_gains), 1, 5)
  
  #correlations <- p_vals <- c()
  sign_species <- c('Akkermansia muciniphila', 'Bacteroides vulgatus', 'Bacteroides ovatus', 
                    'Bacteroides fragilis', 'Bacteroides thetaiotaomicron')
  for (specie in sign_species){
    print(specie)
    cor <- cor.test(as.numeric(body_weight[4,]), as.numeric(species_gains[rownames(species_gains)==specie,t4]))#, method='spearman')
    print(cor)
    #correlations <- c(correlations, cor$estimate)
   # p_vals <- c(p_vals, cor$p.value)
  }
  species_gains$rho <- correlations
  species_gains$p_val <- p_vals
  species_gains$p_val_corr <- p_vals*nrow(species_gains)
  species_gains$taxon<-rownames(species_gains)
  species_gains <- arrange(species_gains, p_val)
  write.csv(species_gains, paste0('./correlations_microbiome_weight/microbiome_changes_mice_weights_gains_correlation_', level, '.csv'))
  which(apply(species_gains, 1, function(row) all(row <= 0))) # which species have all decreased with time - NONE
  which(apply(species_gains, 1, function(row) all(row >= 0))) # which species have all increased with time - NONE
  # None of the species has a signficant correlation with the body weight gain
  for (i in 1:nrow(species_gains[species_gains$p_val<0.05,])) {
    png(paste0('./correlations_microbiome_weight/Correlation_', level, '_', species_gains$taxon[i], '_gains.png'))
    print(plot(as.numeric(species_gains[i,1:12]), as.numeric(body_weight[4,]), xlab = 'Taxon abundance change', ylab = 'body weight gains', 
               main = paste0(species_gains$taxon[i], '\nSpearman rho = ', round(species_gains$rho[i], 2),
                             '\np-val = ', round(species_gains$p_val[i], 2))))
    dev.off()
  }
#}

de_taxa <- rownames(resOrdered_S[resOrdered_S$padj<0.05,])
species_gains[species_gains$taxon%in%de_taxa,]

############# Correlate species abundances with body weights (mice only) ####################
# for (level in c('P', 'C', 'O', 'F', 'G', 'S')){
#   level<-'S'
#   data <- read.csv(paste0('split_file_combined_normalized_16S_', level, '.csv'), header=T, stringsAsFactors = F) 
#   data$level <- data$X <- NULL
#   body_weight <- read.csv('./mice_weights_T0_T4.csv', header=T, stringsAsFactors = F, row.names = 1)
#   body_weight[13,]<- rowMeans(body_weight[c('W3', 'W4', 'W5'),])
#   body_weight <- body_weight[c('HB3', 13),]
#   # body_weight[3,]<- body_weight[2,]-body_weight[1,]
#   # body_weight[4,]<- body_weight[3,]/body_weight[1,]*100
#   # tutaj polczyc srednia
#   body_weight_1row <- data.frame(matrix(nrow =1, ncol=24))
#   colnames(body_weight_1row) <- colnames(data)[2:ncol(data)]
#   body_weight_1row[1,t4]<-body_weight[2,]
#   body_weight_1row[1,t0]<-body_weight[1,]
#   rownames(data)<-data$taxon
#   data$taxon <- NULL
#   data <- data[rowSums(data)>19,]
#   
#   correlations <- p_vals <- c()
#   for (row in 1:nrow(data)){
#     cor <- cor.test(as.numeric(body_weight_1row[1,]), as.numeric(data[row,1:ncol(data)]), method='spearman')
#     correlations <- c(correlations, cor$estimate)
#     p_vals <- c(p_vals, cor$p.value)
#   }
#   
#   data$taxon <- rownames(data)
#   data$rho <- correlations
#   data$p_val <- p_vals
#   data$p_val_corr <- p_vals*nrow(data)
#   data <- arrange(data, p_val)
#   write.csv(data, paste0('./correlations_microbiome_weight/microbiome_mice_weights_', level, '.csv'))
#   
#   for (i in 1:nrow(data[data$p_val<0.05,])) {
#     png(paste0('./correlations_microbiome_weight/Correlation_', level, '_', data$taxon[i], '.png'))
#     print(plot(as.numeric(data[i,grepl('X', colnames(data))]), as.numeric(body_weight_1row[1,]), xlab = 'Taxon abundance', ylab = 'Body weight [g]', 
#                main = paste0(data$taxon[i], '\nSpearman rho = ', round(data$rho[i], 2),
#                              '\np-val = ', round(data$p_val[i], 2))))
#     print(points(as.numeric(data[i,t4]), as.numeric(body_weight_1row[1,t4]), col='red', pch=16))
#     legend("bottomright", c('T0', 'T4'), pch=c(1, 19), col=c('black', 'red'))
#     dev.off()
#   }
# }
# # Subsetting to the Differentially Abundant taxa
# de_taxa <- rownames(resOrdered_S[resOrdered_S$padj<0.05,])
# data[data$taxon%in%de_taxa,]
# 
# for (taxon in de_taxa) {
#   png(paste0('./correlations_microbiome_weight/Correlation_', level, '_', taxon, '_DE_taxon.png'))
#   print(plot(as.numeric(data[data$taxon==taxon,grepl('X', colnames(data))]), as.numeric(body_weight_1row[1,]), xlab = 'Taxon abundance', ylab = 'Body weight [g]', 
#              main = paste0(taxon, '\nSpearman rho = ', round(data$rho[data$taxon==taxon], 2),
#                            '\np-val = ', round(data$p_val[data$taxon==taxon], 2))))
#   print(points(as.numeric(data[data$taxon==taxon,t4]), as.numeric(body_weight_1row[1,t4]), col='red', pch=16))
#   legend("bottomright", c('T0', 'T4'), pch=c(1, 19), col=c('black', 'red'))
#   dev.off()
#   if (grepl('Lactobacillus|Veillo', taxon)==TRUE){
#     png(paste0('./correlations_microbiome_weight/Correlation_', level, '_', taxon, '_DE_taxon.png'))
#     print(plot(as.numeric(data[data$taxon==taxon,grepl('X', colnames(data))]), as.numeric(body_weight_1row[1,]), 
#                xlim = c(0,50),
#                xlab = 'Taxon abundance', ylab = 'Body weight [g]', 
#                main = paste0(taxon, '\nSpearman rho = ', round(data$rho[data$taxon==taxon], 2),
#                              '\np-val = ', round(data$p_val[data$taxon==taxon], 2))))
#     print(points(as.numeric(data[data$taxon==taxon,t4]), as.numeric(body_weight_1row[1,t4]), col='red', pch=16))
#     legend("bottomright", c('T0', 'T4'), pch=c(1, 19), col=c('black', 'red'))
#     dev.off()
#   }
# 
# }
# None of the species has a signficant correlation with the body weight after correction for multiple testing

################### Correlate species abundances with behavioral parameters
level<-'G'
data <- read.csv(paste0('split_file_combined_normalized_16S_', level, '.csv'), header=T, stringsAsFactors = F)
data$level <- data$X <- NULL
behavior <- read.csv('./mice_behaviors_2.csv', header=T, stringsAsFactors = F, row.names = 1)

rownames(data)<-data$taxon
data$taxon <- NULL
data <- data[rowMeans(data)>50,]
colnames(data)[grepl(".1",colnames(data), fixed=TRUE)] <- 
  gsub(".1", "_T4", colnames(data)[grepl(".1",colnames(data), fixed=TRUE)], fixed=TRUE)
colnames(data)[!grepl('T4', colnames(data))] <- paste0(colnames(data)[!grepl('T4', colnames(data))], '_T0')
colnames(data) <- substr(colnames(data), 2, 8)
colnames(behavior) <- substr(colnames(behavior), 2, 8)
correlations <- p_vals <- species_df <- beh_df <-c()
sign_species <- c('Akkermansia muciniphila', 'Bacteroides vulgatus', 'Bacteroides ovatus', 
                  'Bacteroides fragilis', 'Bacteroides thetaiotaomicron')

correlations <- p_vals <- species_df <- beh_df <-c()
for (specie in rownames(data)) { #sign_species , rownames(data)
  for (row_nr in 1:nrow(behavior)) {
    cor <- cor.test(as.numeric(data[rownames(data)==specie,]), as.numeric(behavior[row_nr, colnames(data)]), method='pearson')
    png(paste0('./correlations_microbiome_phenotype/corr_', specie, '_', rownames(behavior)[row_nr], '_Pearson.png'))
    print(plot(as.numeric(data[rownames(data)==specie,]), as.numeric(behavior[row_nr, colnames(data)]),
              xlab = specie,
              ylab=rownames(behavior)[row_nr],
              main = paste0('\nPearson R = ', round(cor$estimate, 2),
                            '\np-val = ', round(cor$p.value, 2))))
    print(points(as.numeric(data[rownames(data)==specie,colnames(data)[grepl('T0', colnames(data))]]),
                as.numeric(behavior[row_nr, colnames(data)[grepl('T0', colnames(data))]]), col='red', pch=16))
    dev.off()
    correlations <- c(correlations, cor$estimate)
    p_vals <- c(p_vals, cor$p.val)
    species_df <- c(species_df, specie)
    beh_df <- c(beh_df, rownames(behavior)[row_nr])
  }
}
df <- data.frame('corr' = correlations, 'p' = p_vals, 'specie' = species_df, 'behavioral_feature' = beh_df, stringsAsFactors = F)
df$p_val_corr <- df$p*nrow(df)
df <- arrange(df, p)
write.csv(df, paste0('./correlations_microbiome_phenotype/microbiome_mice_phenotype_', level, '_Pearson.csv'))


plot(as.numeric(behavior['energy_intake_HF_channel',]), as.numeric(behavior['weight',]), 
     xlab='energy_intake_HF_channel',
     ylab='weight', main = 'Pearson R = -0.55\np=0.005')
points(as.numeric(behavior['energy_intake_HF_channel',grepl('T0', colnames(behavior))]), as.numeric(behavior['weight',grepl('T0', colnames(behavior))]), col='red', pch=16)
###### Differences between T0 and T4
t4 <- seq(1, 24, by=2)
t0 <- seq(2, 24, by=2)
species_gains <- data[,t4] - data[,t0]
t4 <- 13:24
t0 <- 1:12
behav_gains <- behavior[,t4] - behavior[,t0]

correlations <- p_vals <- species_df <- beh_df <-c()
for (specie in sign_species) { #sign_species , rownames(species_gains)
  for (row_nr in 1:nrow(behav_gains)) {
    cor <- cor.test(as.numeric(species_gains[rownames(species_gains)==specie,]), as.numeric(behav_gains[row_nr, colnames(species_gains)]), method='spearman')
    png(paste0('./correlations_microbiome_phenotype/corr_Diff_', specie, '_', rownames(behav_gains)[row_nr], '.png'))
    print(plot(as.numeric(species_gains[rownames(species_gains)==specie,]), as.numeric(behav_gains[row_nr, colnames(species_gains)]),
               xlab = specie,
               ylab=rownames(behav_gains)[row_nr],
               main = paste0('\nSpearman rho = ', round(cor$estimate, 2),
                             '\np-val = ', round(cor$p.value, 2)), pch=19))
    #print(points(as.numeric(species_gains[rownames(species_gains)==specie,colnames(species_gains)[grepl('T0', colnames(species_gains))]]),
    #             as.numeric(behav_gains[row_nr, colnames(species_gains)[grepl('T0', colnames(species_gains))]]), col='red', pch=17))
    dev.off()
    correlations <- c(correlations, cor$estimate)
    p_vals <- c(p_vals, cor$p.val)
    species_df <- c(species_df, specie)
    beh_df <- c(beh_df, rownames(behav_gains)[row_nr])
  }
}
df <- data.frame('corr' = correlations, 'p' = p_vals, 'specie' = species_df, 'behavioral_feature' = beh_df, stringsAsFactors = F)
df$p_val_corr <- df$p*nrow(df)
df <- arrange(df, p)
write.csv(df, paste0('./correlations_microbiome_phenotype/microbiome_mice_phenotype_Diffs_', level, '.csv'))


#################### Compare numbers of detected species in mice and human data (Biagi et al. 2014) (Venn diagram) #################### 

# Numbers of species (Venn)
human <- read.csv('./normalized_files_combined_SK_biagi_S.csv', stringsAsFactors = F, header=T)
human$level<-NULL
colnames(human)<-c('taxon', paste0(rep('DOWN0', 9), 1:9), paste0(rep('DOWN', 8), 10:17), paste0(rep('CTRL0', 9), 1:9),  paste0(rep('CTRL', 7), 10:16))
human <- human[rowSums(human[,2:ncol(human)])>19,]

data <- read.csv('split_file_combined_normalized_16S_S.csv', header=T, stringsAsFactors = F) 
data$level <- data$X <- NULL
data <- data[rowSums(data[,2:ncol(data)])>19,]

library(eulerr)
png('venn_human_mice.png')
plot(euler(list('Human\nn=142' = human$taxon, 'Mice\nn=353' = data$taxon)), fills = c('#7CAE00', '#C77CFF'))
dev.off()

#################### Compare numbers of species (mice and humans) per genotype ####################
library(eulerr)
human <- read.csv('./normalized_files_combined_SK_biagi_S.csv', stringsAsFactors = F, header=T)
human$level<-NULL
colnames(human)<-c('taxon', paste0(rep('DOWN0', 9), 1:9), paste0(rep('DOWN', 8), 10:17), paste0(rep('CTRL0', 9), 1:9),  paste0(rep('CTRL', 7), 10:16))

data <- read.csv('split_file_combined_normalized_16S_S.csv', header=T, stringsAsFactors = F) 
data$level <- data$X <- NULL

human_DS <- human[,grepl('DOWN|taxon', colnames(human))]
human_DS <- human_DS[rowSums(human_DS[,2:ncol(human_DS)])>9,]
human_WT <- human[,grepl('CTRL|taxon', colnames(human))]
human_WT <- human_WT[rowSums(human_WT[,2:ncol(human_WT)])>9,]
colnames(data) <- c('taxon', 'WT1_T4', 'WT1_T0', 'WT2_T4', 'WT2_T0', 'WT3_T4', 'WT3_T0', 'WT4_T4', 'WT4_T0', 'WT5_T4', 'WT5_T0', 'WT6_T4', 'WT6_T0',
                    'DS1_T4', 'DS1_T0', 'DS2_T4', 'DS2_T0', 'DS3_T4', 'DS3_T0', 'DS4_T4', 'DS4_T0', 'DS5_T4', 'DS5_T0', 'DS6_T4', 'DS6_T0')
mice_DS <- data[, grepl('DS|taxon', colnames(data))]
mice_DS <- mice_DS[rowSums(mice_DS[,2:ncol(mice_DS)])>9,]
mice_WT <- data[, grepl('WT|taxon', colnames(data))]
mice_WT <- mice_WT[rowSums(mice_WT[,2:ncol(mice_WT)])>9,]

# human
png('venn_human_DS_WT.png')
plot(euler(list('Human DS\nn = 147' = human_DS$taxon, 'Human healthy\nn = 130' = human_WT$taxon)), fills = c('#FA552F', '#599799'))
dev.off()

# humans and mice
png('venn_human_mice_DS_WT.png')
plot(euler(list('Human healthy\nn = 130' = human_WT$taxon, 'Human DS\nn = 147' = human_DS$taxon, 
                'Mice WT\nn = 354' = mice_WT$taxon, 'Mice DS\nn = 325' = mice_DS$taxon)), fills = c('#599799', '#FA552F', '#00BFC4', '#F8766D'))
dev.off()

#################### Correlate mouse with mouse abundances data and human with human, and compare them #################### 

human <- read.csv('./normalized_files_combined_SK_biagi_S.csv', stringsAsFactors = F, header=T)
human$level<-NULL
colnames(human)<-c('taxon', paste0(rep('DOWN0', 9), 1:9), paste0(rep('DOWN', 8), 10:17), paste0(rep('CTRL0', 9), 1:9),  paste0(rep('CTRL', 7), 10:16))

data <- read.csv('split_file_combined_normalized_16S_S.csv', header=T, stringsAsFactors = F) 
data$level <- data$X <- NULL

common_species <- human$taxon[human$taxon%in%data$taxon]

library(ggplot2)
library(scales)
library(ggrepel)
library(data.table)
library(reshape2)
library(grid)

data <- data[data$taxon%in%common_species,]
colnames(data) <- c('taxon', 'WT1_T4', 'WT1_T0', 'WT2_T4', 'WT2_T0', 'WT3_T4', 'WT3_T0', 'WT4_T4', 'WT4_T0', 'WT5_T4', 'WT5_T0', 'WT6_T4', 'WT6_T0',
                    'DS1_T4', 'DS1_T0', 'DS2_T4', 'DS2_T0', 'DS3_T4', 'DS3_T0', 'DS4_T4', 'DS4_T0', 'DS5_T4', 'DS5_T0', 'DS6_T4', 'DS6_T0')
data_corr <- human[human$taxon%in%common_species,]
data_corr <- data_corr[order(match(data_corr$taxon,data$taxon)),]
data_corr_test <- cbind(data_corr,data[,names(data) != "taxon"])
row.names(data_corr_test) <- data_corr_test$taxon
data_corr_test$taxon <- NULL
data_corr_test <- data_corr_test[rowMeans(data_corr_test)>19,]
# plot(1:nrow(data_corr_test), data_corr_test[,1])
# points(1:nrow(data_corr_test), data_corr_test[,2], col='red')
# axis(1, 1:nrow(data_corr_test), rownames(data_corr_test), las=2)

# Normalise:
sums <- apply(data_corr_test, 2, sum)
quartile <- quantile(sums)[[3]] # second quartile
data_corr_norm <- data_corr_test
for (i in 1:nrow(data_corr_test)){
  data_corr_norm[i, ] <- data_corr_test[i,] * quartile / sums
}
data_corr_norm <- round(data_corr_norm)

WT_human <- colnames(data_corr_norm)[grepl('CTRL', colnames(data_corr_norm))]
mice1 <- WT_human
mice2 <- mice1 [ mice1 != mice1[1]]
WT_human_kor <- c()
WT_human_p <- c()
cnt<-0
for (i in mice1) {
  for (j in mice2) {
    if (i!=j){
      cat(i, ' ', j, '\n')
      k<- cor.test(data_corr_norm[,i], data_corr_norm[,j])
      WT_human_kor <- c(WT_human_kor, k$estimate)
      WT_human_p <- c(WT_human_p, k$p.value)
      cnt<-cnt+1 } } 
  mice2 <- mice2 [ mice2!=i ]
}

DS_human <- colnames(data_corr_norm)[grepl('DOWN', colnames(data_corr_norm))]
mice1 <- DS_human
mice2 <- mice1 [ mice1 != mice1[1]]
DS_human_kor <- c()
DS_human_p <- c()
cnt<-0
for (i in mice1) {
  for (j in mice2) {
    if (i!=j){
      cat(i, ' ', j, '\n')
      k<- cor.test(data_corr_norm[,i], data_corr_norm[,j])
      DS_human_kor <- c(DS_human_kor, k$estimate)
      DS_human_p <- c(DS_human_p, k$p.value)
      cnt<-cnt+1 } } 
  mice2 <- mice2 [ mice2!=i ]
}

WT_mice <- colnames(data_corr_norm)[grepl('WT', colnames(data_corr_norm))]
mice1<- WT_mice
mice2 <- mice1 [ mice1 != mice1[1]]
WT_mice_kor <- c()
WT_mice_p <- c()
cnt<-0
for (i in mice1) {
  for (j in mice2) {
    if (i!=j){
      cat(i, ' ', j, '\n')
      k<- cor.test(data_corr_norm[,i], data_corr_norm[,j])
      WT_mice_kor <- c(WT_mice_kor, k$estimate)
      WT_mice_p <- c(WT_mice_p, k$p.value)
      cnt<-cnt+1 } } 
  mice2 <- mice2 [ mice2!=i ]
}

DS_mice <- colnames(data_corr_norm)[grepl('DS', colnames(data_corr_norm))]
mice1<- DS_mice
mice2 <- mice1 [ mice1 != mice1[1]]
DS_mice_kor <- c()
DS_mice_p <- c()
cnt<-0
for (i in mice1) {
  for (j in mice2) {
    if (i!=j){
      cat(i, ' ', j, '\n')
      k<- cor.test(data_corr_norm[,i], data_corr_norm[,j])
      DS_mice_kor <- c(DS_mice_kor, k$estimate)
      DS_mice_p <- c(DS_mice_p, k$p.value)
      cnt<-cnt+1 } } 
  mice2 <- mice2 [ mice2!=i ]
}


maks <- max(length(WT_human_kor), length(DS_human_kor), length(WT_mice_kor), length(DS_mice_kor))

df = data.frame('WT_human_kor' = c(WT_human_kor, rep(NA, maks-length(WT_human_kor))),
          'DS_human_kor' = c(DS_human_kor, rep(NA, maks-length(DS_human_kor))),
          'WT_mice_kor' = c(WT_mice_kor, rep(NA, maks-length(WT_mice_kor))),
          'DS_mice_kor' = c(DS_mice_kor, rep(NA, maks-length(DS_mice_kor))))


class(df)
data_plot_corr<-melt(df)

ggplot(data_plot_corr, aes(x=variable, y=value)) +
  geom_boxplot(fill = c('#7CAE00', '#7CAE00', '#C77CFF', '#C77CFF'), alpha =0.8) +
  ylab('Pearson R') + xlab('Condition') +
  scale_y_continuous(breaks = seq(0, 1, by = 0.1))

ggsave('correlations_of_samples_within_genotypes_mice_and_humans.png')

wilcox.test(c(WT_human_kor), c(DS_human_kor))
wilcox.test(c(WT_mice_kor), c(DS_mice_kor))


#################### Correlate mice taxonomic abundances data with human taxonomic abundances data  #################### not interesting

# WT_human <- colnames(data_corr_norm)[grepl('CTRL', colnames(data_corr_norm))]
# WT_mice <- colnames(data_corr_norm)[grepl('WT', colnames(data_corr_norm))]
# 
# WT_hum_mice_kor <- c()
# WT_hum_mice_p <- c()
# for (i in WT_human) {
#   for (j in WT_mice) {
#     if (i!=j){
#       cat(i, ' ', j, '\n')
#       k<- cor.test(data_corr_norm[,i], data_corr_norm[,j], method='spearman')
#       WT_hum_mice_kor <- c(WT_hum_mice_kor, k$estimate)
#       WT_hum_mice_p <- c(WT_hum_mice_p, k$p.value)
#       } } 
#  }
# 
# DS_human <- colnames(data_corr_norm)[grepl('DOWN', colnames(data_corr_norm))]
# DS_mice <- colnames(data_corr_norm)[grepl('DS', colnames(data_corr_norm))]
# 
# DS_hum_mice_kor <- c()
# DS_hum_mice_p <- c()
# 
# for (i in DS_human) {
#   for (j in DS_mice) {
#     if (i!=j){
#       cat(i, ' ', j, '\n')
#       k<- cor.test(data_corr_norm[,i], data_corr_norm[,j], method='spearman')
#       DS_hum_mice_kor <- c(DS_hum_mice_kor, k$estimate)
#       DS_hum_mice_p <- c(DS_hum_mice_p, k$p.value)
#     } } 
# }
# 
# maks <- max(length(WT_hum_mice_kor), length(DS_hum_mice_kor))
# 
# df = data.frame('WT_human_mice_kor' = c(WT_hum_mice_kor, rep(NA, maks-length(WT_hum_mice_kor))),
#                 'DS_human_mice_kor' = c(DS_hum_mice_kor, rep(NA, maks-length(DS_hum_mice_kor))))
# 
# data_plot_corr<-melt(df)
# 
# ggplot(data_plot_corr, aes(x=variable, y=value)) +
#   geom_boxplot(fill = c('#7CAE00', '#C77CFF'), alpha =0.8) +
#   ylab('Spearman rho') + xlab('Condition') +
#   scale_y_continuous(breaks = seq(0, 1, by = 0.1))
# 
# #ggsave('correlations_of_samples_within_genotypes_mice_and_humans.png')
# 
# wilcox.test(c(WT_hum_mice_kor), c(DS_hum_mice_kor))
# wilcox.test(c(WT_mice_kor), c(DS_mice_kor))
# 

#################### Clustering of the human data alone ####################

library(vegan)
library(dendextend)

data_hcl <- human
rownames(data_hcl) <- data_hcl$taxon
data_hcl$taxon <- NULL
data_hcl <- data_hcl[rowSums(data_hcl)>19,]
data_hcl<-data.frame(t(data_hcl))
dist_matr <- vegdist(data_hcl,method="canberra") # canberra daje 3 klastry z czego 2 sa dosyc specyficzne i ward.D2 / complete poki co w miare ok
dend<-as.dendrogram(hclust(dist_matr, method='ward.D2')) ##
#labels_colors(dend)<-c(rep('#00BFC4', 8), '#F8766D', rep('#00BFC4', 3), '#F8766D', '#00BFC4', rep('#F8766D', 10))
png(file="HCL_strain_S_human.png")
#par(mar=c(5,4.1,2.1,2.1))
plot(dend)
legend("topright", c('WT', 'DS'), pch=19, col=c('#00BFC4', '#F8766D'))
dev.off()

dev.off() 

####################  Clustering of the human and mice data #################### not interesting
# data_hcl <- data_corr_norm
# #rownames(data_hcl) <- data_hcl$taxon
# #data_hcl$taxon <- NULL
# #data_hcl <- data_hcl[rowSums(data_hcl)>19,]
# data_hcl<-data.frame(t(data_hcl))
# 
# for (meth_dist in c("manhattan", "euclidean", "canberra", "clark", "bray", "chao") ) {
#   for ( meth_clust in c("ward.D", "ward.D2", "single", "complete", "average" , "mcquitty", "median" )){
# dist_matr <- vegdist(data_hcl,method=meth_dist) # canberra daje 3 klastry z czego 2 sa dosyc specyficzne i ward.D2 / complete poki co w miare ok
# dend<-as.dendrogram(hclust(dist_matr, method=meth_clust)) ##
# plot(dend, main=paste0(meth_dist, ' ', meth_clust))
#   }
# }
# 
# data_corr_norm
#################### Correlate human microbiome data with metadata ####################
#################### Build a model for predicting obesity or mental disability ####################

# Read-in the metadata files
library(dplyr)
library(ggplot2)
library(ggrepel)
cognitive <- read.csv('Biagi_cognitive_impairment.csv', header=T, stringsAsFactors = F)
clinical <- read.csv('Biagi_demographic_and_clinical_features.csv', header=T, stringsAsFactors = F)
food <- read.csv('Biagi_percentages_of_food_categories.csv', header=T, stringsAsFactors = F)

rownames(cognitive)<-cognitive$SampleID
cognitive$SampleID<-NULL #I'm removing because it's multiplicated
clinical$SampleID<-NULL 
food$SampleID<-NULL 
meta <- cbind(cognitive, clinical, food)
meta$SampleID<-rownames(meta)
#meta<-data.frame(t(meta), stringsAsFactors = F)
#colnames(meta) <- substr(colnames(meta),start = 2, stop = 5)


human <- read.csv('./split_file_combined_normalized_Biagi_S.csv', stringsAsFactors = F, header=T)
human$X <- NULL
rownames(human) <- human$taxon
colnames(human) <- substr(colnames(human), 2, 7)
human[,c(1,2)]<-NULL
healthy <- human[,grepl('1134', colnames(human))]
human[,grepl('1134', colnames(human))] <- NULL
#human[, ] <- lapply(human[, ], as.character)


# reoder columns of 'meta' to the same sample order as in 'human'
mapping_sample_names <- read.csv('mapping_sample_names.csv', stringsAsFactors =F)
s_order <- match(mapping_sample_names$jobID, colnames(human))
human <- human[,s_order]
colnames(human) <- rownames(meta)
human <- data.frame(t(human))
human <- human[,colMeans(human)>5]

df <- cbind(meta, human)
healthy <- data.frame(t(healthy))
healthy <- healthy[,colnames(healthy)%in%colnames(df)] #Removing bacteria which were removed in the DS samples as low count
# wybrac odp bakterie
healthy <- cbind(data.frame(matrix(NA, ncol=31, nrow = nrow(healthy))), healthy)
colnames(healthy)[1:31] <- colnames(df)[1:31]
healthy$Cognitive.impairment <- 'healthy'
df <- rbind(df, healthy)
sign_species <- c('Akkermansia.muciniphila', 'Bacteroides.vulgatus', 'Bacteroides.ovatus', 
                  'Bacteroides.fragilis', 'Bacteroides.thetaiotaomicron')#, 'Clostridium.saccharolyticum')
meta_columns <-c("ABC.irritability", "ABC.lethargy", "ABC.stereotypy", "ABC.hyperactivity", "ABC.inappropriate.speech", 
                 "ABC.TOTAL.SCORE", "VABS.communication", "VABS.daily.living.skills", "VABS.socialization", "VABS.motor.skills", 
                 "VABS.TOTAL.SCORE", "Age..years.", "Height..cm.", "Weight..kg.", "Belly..cm.", "BMI", 
                 "Bread..cereal..pasta..grain", "Legumes..rice..potatoes", "Meats..egg", "Dairy.products", "Fruit",
                 "Vegetables", "Desserts")
meta_classes <- c('Gender', "Weight.classification", "Dietary.habits..food.intake.", "GI.problem", "Karyotype", "LT4")
df_ds <- df[!df$Cognitive.impairment=='healthy',]
for (specie in sign_species) {
  for (meta_cl in meta_columns) {
    print(meta_cl)
  print(specie)
  position_for_plot_text <- min(df_ds[, meta_cl]) + (max(df_ds[, meta_cl]) - min(df_ds[, meta_cl])) / 2
  c <- cor.test(df_ds[,specie], df_ds[, meta_cl])
  g<-ggplot(df_ds, aes(x = df_ds[,meta_cl], y = df_ds[,specie])) +
    ylab(specie)+
    xlab(meta_cl) +
    geom_point()+
    #scale_color_manual(limits = c('mild', 'moderate', 'severe'), values=c('orange', 'brown1', 'brown4'))+
    annotate("text", x = position_for_plot_text, y=max(df_ds[,specie], na.rm = T), 
             label = paste0('Pearson R = ', round(c$estimate, 2), '\np-val = ', round(c$p.value, 2)))
    
  print(g)
  print(c)
  ggsave(paste0('./correlations_microbiome_weight/human_', meta_cl,'_bacteria_', specie, '.png'))
  }
}

for (specie in sign_species) {
g <- ggplot(df, aes(x = df$Cognitive.impairment, y = df[,specie], color = Cognitive.impairment)) +
  ylab(specie)+
  xlab('Cognitive impairment') +
    scale_color_manual(values = c('lightblue', 'orange', 'brown1', 'brown4')) +
#  ylim(c(1, 1000)) +
    geom_jitter(width = 0.1)
print(g)
ggsave(paste0('./correlations_microbiome_weight/human_cognitive_imp_', specie, '.png'))
}
df_ds$Weight.classification <- factor(df_ds$Weight.classification, levels=c("normal weight", "overweight", "obesity"))
# for (specie in sign_species) {
#     g <- ggplot(df_ds, aes(x = Weight.classification, y = df_ds[,specie], color = Weight.classification, label=BMI)) +
#     ylab(specie)+
#     xlab('Weight classification') +
#     scale_color_manual(values = c('lightblue', 'orange', 'brown1', 'brown4')) +
#       geom_label_repel() + 
#     #  ylim(c(1, 1000)) +
#     geom_jitter(width = 0.1)
#   print(g)
#   ggsave(paste0('human_weight_class_', specie, '.png'))
# }
# 
# cor.test(df$Bacteroides.ovatus, df$ABC.irritability, method='spearman')
# df$Cognitive.impairment_class [df$Cognitive.impairment=='healthy'] <- 1
# df$Cognitive.impairment_class [df$Cognitive.impairment=='mild'] <- 2
# df$Cognitive.impairment_class [df$Cognitive.impairment=='moderate'] <- 3
# df$Cognitive.impairment_class [df$Cognitive.impairment=='severe'] <- 4
# 
# lm(data=df, Cognitive.impairment_class ~ ABC.irritability + ABC.lethargy + ABC.stereotypy + ABC.hyperactivity + ABC.inappropriate.speech + 
#      ABC.TOTAL.SCORE + VABS.communication + VABS.daily.living.skills + VABS.socialization + VABS.motor.skills + VABS.TOTAL.SCORE)
# 
# "ABC.irritability"                        "ABC.lethargy"                           
# [4] "ABC.stereotypy"                          "ABC.hyperactivity"                       "ABC.inappropriate.speech"               
# [7] "ABC.TOTAL.SCORE"                         "VABS.communication"                      "VABS.daily.living.skills"               
# [10] "VABS.socialization"                      "VABS.motor.skills"                       "VABS.TOTAL.SCORE"                       
# [13] "Age..years."                             "Gender"                                  "Height..cm."                            
# [16] "Weight..kg."                             "Belly..cm."                              "BMI"                                    
# [19] "Weight.classification"                   "Dietary.habits..food.intake."            "GI.problem"                             
# [22] "Karyotype"                               "LT4"                                     "Bread..cereal..pasta..grain"            
# [25] "Legumes..rice..potatoes"                 "Meats..egg"                              "Dairy.products"                         
# [28] "Fruit"                                   "Vegetables"                              "Desserts"
#      
#      #Akkermansia.muciniphila +
#      Bacteroides.vulgatus + Bacteroides.ovatus + Bacteroides.fragilis + 
#      Bacteroides.thetaiotaomicron + Alistipes.finegoldii +Butyrivibrio.proteoclasticus)



#################### MDS on human metadata ####################

library(vegan)
data_mds <- meta
data_mds<-data.frame(t(data_mds))
data_mds $SampleID <- data_mds$Karyotype <- NULL
data_mds$Cognitive.impairment <- as.numeric(data_mds$Cognitive.impairment)
data_mds$Gender <- as.numeric(data_mds$Gender)
data_mds$Dietary.habits..food.intake. <- as.numeric(data_mds$Dietary.habits..food.intake.)
data_mds$Weight.classification <- as.numeric(data_mds$Weight.classification)
data_mds$GI.problem <- as.numeric(data_mds$GI.problem)
data_mds$LT4 <- as.numeric(data_mds$LT4)

data_mds[, ] <- lapply(data_mds[, ], as.character)
data_mds[, ] <- lapply(data_mds[, ], as.numeric)

data.classes.gender<-c(as.factor(data_mds$Gender))
data.classes.Cognitive.impairment<-c(as.factor(data_mds$Cognitive.impairment))
data.classes.ABC.TOTAL.SCORE<-c(as.factor(data_mds$ABC.TOTAL.SCORE))
data.classes.VABS.TOTAL.SCORE<-c(as.factor(data_mds$VABS.TOTAL.SCORE))
data.classes.Weight.classification<-c(as.factor(data_mds$Weight.classification))
data.classes.GI.problem<-c(as.factor(data_mds$GI.problem))
data.classes.LT4<-c(as.factor(data_mds$LT4))


# https://websites.pmc.ucsc.edu/~mclapham/Rtips/ordination.htm
PCoA.res<-capscale(data_mds~1,distance="canberra", dfun=vegdist) #bray
dis <- vegdist(data_mds,method="canberra")

eig<-PCoA.res$CA$eig # percentages of each MDS component
percentages_explained <- eig / sum(eig)

plot(scores(PCoA.res, choices=c(1,2), display="sites"), col=data.classes.gender, pch=19)
plot(scores(PCoA.res, choices=c(3,4), display="sites"), col=data.classes.gender, pch=19)

plot(scores(PCoA.res, choices=c(1,2), display="sites"), col=data.classes.Cognitive.impairment, pch=19) # tutaj jest trend
text(scores(PCoA.res, choices=c(1,2), display="sites"), as.character(meta['Cognitive.impairment',]), col=data.classes.Cognitive.impairment)
plot(scores(PCoA.res, choices=c(3,4), display="sites"), col=data.classes.Cognitive.impairment, pch=19)

plot(scores(PCoA.res, choices=c(1,2), display="sites"), col=data.classes.ABC.TOTAL.SCORE, pch=19)
plot(scores(PCoA.res, choices=c(3,4), display="sites"), col=data.classes.ABC.TOTAL.SCORE, pch=19)

plot(scores(PCoA.res, choices=c(1,2), display="sites"), col=data.classes.VABS.TOTAL.SCORE, pch=19)
plot(scores(PCoA.res, choices=c(3,4), display="sites"), col=data.classes.VABS.TOTAL.SCORE, pch=19)

plot(scores(PCoA.res, choices=c(1,2), display="sites"), col=data.classes.Weight.classification, pch=19)
text(scores(PCoA.res, choices=c(1,2), display="sites"), as.character(meta['Weight.classification',]), col=data.classes.Weight.classification)
plot(scores(PCoA.res, choices=c(3,4), display="sites"), col=data.classes.Weight.classification, pch=19)

plot(scores(PCoA.res, choices=c(1,2), display="sites"), col=data.classes.GI.problem, pch=19)
plot(scores(PCoA.res, choices=c(3,4), display="sites"), col=data.classes.GI.problem, pch=19)

plot(scores(PCoA.res, choices=c(1,2), display="sites"), col=data.classes.LT4, pch=19)
plot(scores(PCoA.res, choices=c(3,4), display="sites"), col=data.classes.LT4, pch=19)


#, xlab = paste(c("MDS3 \n", as.character(round(percentages_explained[[3]]*100, 2)) , "%"), collapse=""))
#text(scores(PCoA.res, choices=c(3,4), display="sites"), labels(dis), col=data.classes.genotype, pos=1)
mtext(side = 2, text = paste(c(as.character(round(percentages_explained[[4]]*100, 2)) , "%"), collapse=""), line = 2)
legend("topleft", c('WT', 'DS'), pch=19, col=c('#00BFC4','#F8766D'))
dev.off()

scores<-data.frame(scores(PCoA.res, choices=c(3,4), display="species"))
order<-order(abs(scores$MDS3), decreasing=TRUE)
scores[order,]
write.table(scores[order,], file="Scores_MDS_Bray_S_strains.csv", sep=',', row.names = TRUE, col.names = TRUE)

